
package service;

import model.*;
import java.io.*;
import java.util.*;

public class EmployeeService {

    private Map<Integer, Employee> employees = new HashMap<>();
    private int nextId = 1;

    public Employee addEmployee(String type, String name, String surname, int year) {
        Employee e;
        if (type.equals("analyst")) {
            e = new Analyst(nextId++, name, surname, year);
        } else {
            e = new SecuritySpecialist(nextId++, name, surname, year);
        }
        employees.put(e.getId(), e);
        return e;
    }

    public void addCooperation(int id1, int id2, String quality) {
        Employee e1 = employees.get(id1);
        Employee e2 = employees.get(id2);
        if (e1 != null && e2 != null) {
            e1.addCooperation(e2, quality);
        }
    }

    public void removeEmployee(int id) {
        employees.remove(id);
    }

    public void findEmployee(int id) {
        if (employees.containsKey(id)) {
            employees.get(id).printInfo();
        }
    }

    public void printSorted() {
        employees.values().stream()
                .sorted(Comparator.comparing(Employee::getLastName))
                .forEach(Employee::printInfo);
    }

    public void statistics() {
        Employee max = null;
        int maxCount = -1;
        for (Employee e : employees.values()) {
            if (e.getCooperations().size() > maxCount) {
                max = e;
                maxCount = e.getCooperations().size();
            }
        }
        if (max != null) {
            System.out.println("Najviac vazieb: " + max.getLastName());
        }
    }

    public void saveToFile(String file) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));
        oos.writeObject(employees);
        oos.close();
    }

    public void loadFromFile(String file) throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file));
        employees = (Map<Integer, Employee>) ois.readObject();
        ois.close();
    }
}
