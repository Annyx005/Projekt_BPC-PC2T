
package model;

public class Analyst extends Employee {

    public Analyst(int id, String firstName, String lastName, int birthYear) {
        super(id, firstName, lastName, birthYear);
    }

    @Override
    public void performSkill() {
        System.out.println("Analytik analyzuje spoluprace...");
    }
}
