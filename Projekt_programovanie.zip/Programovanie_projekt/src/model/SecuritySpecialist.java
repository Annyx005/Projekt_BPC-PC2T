
package model;

public class SecuritySpecialist extends Employee {

    public SecuritySpecialist(int id, String firstName, String lastName, int birthYear) {
        super(id, firstName, lastName, birthYear);
    }

    @Override
    public void performSkill() {
        double score = 0;
        for (Cooperation c : cooperations) {
            switch (c.getQuality()) {
                case "dobra": score += 1; break;
                case "prumerna": score += 2; break;
                case "spatna": score += 3; break;
            }
        }
        System.out.println("Rizikove skore: " + score);
    }
}
