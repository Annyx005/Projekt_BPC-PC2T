
package model;

import java.io.Serializable;
import java.util.*;

public abstract class Employee implements Serializable {
    protected int id;
    protected String firstName;
    protected String lastName;
    protected int birthYear;
    protected List<Cooperation> cooperations = new ArrayList<>();

    public Employee(int id, String firstName, String lastName, int birthYear) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthYear = birthYear;
    }

    public void addCooperation(Employee colleague, String quality) {
        cooperations.add(new Cooperation(colleague, quality));
    }

    public int getId() { return id; }
    public String getLastName() { return lastName; }
    public List<Cooperation> getCooperations() { return cooperations; }

    public abstract void performSkill();

    public void printInfo() {
        System.out.println(id + ": " + firstName + " " + lastName + " (" + birthYear + ")");
        System.out.println("Spoluprace: " + cooperations.size());
    }
}
