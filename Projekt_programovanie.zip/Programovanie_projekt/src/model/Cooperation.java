
package model;

import java.io.Serializable;

public class Cooperation implements Serializable {
    private Employee colleague;
    private String quality;

    public Cooperation(Employee colleague, String quality) {
        this.colleague = colleague;
        this.quality = quality;
    }

    public String getQuality() { return quality; }
    public Employee getColleague() { return colleague; }
}
