
package main;

import service.EmployeeService;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        EmployeeService service = new EmployeeService();

        while (true) {
            System.out.println("\n1-Pridat 2-Spolupraca 3-Vyhladat 4-Statistika 5-Ulozit 6-Nacitat 0-Koniec");
            int c = sc.nextInt();

            switch (c) {
                case 1:
                    System.out.print("Typ: ");
                    String t = sc.next();
                    System.out.print("Meno: ");
                    String n = sc.next();
                    System.out.print("Priezvisko: ");
                    String s = sc.next();
                    System.out.print("Rok: ");
                    int y = sc.nextInt();
                    service.addEmployee(t, n, s, y);
                    break;

                case 2:
                    System.out.print("ID1: ");
                    int id1 = sc.nextInt();
                    System.out.print("ID2: ");
                    int id2 = sc.nextInt();
                    System.out.print("Kvalita: ");
                    String q = sc.next();
                    service.addCooperation(id1, id2, q);
                    break;

                case 3:
                    System.out.print("ID: ");
                    service.findEmployee(sc.nextInt());
                    break;

                case 4:
                    service.statistics();
                    break;

                case 5:
                    service.saveToFile("data.ser");
                    break;

                case 6:
                    service.loadFromFile("data.ser");
                    break;

                case 0:
                    return;
            }
        }
    }
}
